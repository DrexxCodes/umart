declare module 'confetti-js';
