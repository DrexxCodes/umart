import { NextRequest, NextResponse } from 'next/server'
import { adminDb, adminAuth } from '@/lib/firebase-admin'

export async function GET(req: NextRequest) {
  try {
    const authHeader = req.headers.get('authorization')
    if (!authHeader?.startsWith('Bearer ')) {
      return NextResponse.json(
        { success: false, error: 'Unauthorized' },
        { status: 401 }
      )
    }

    const token = authHeader.substring(7)
    let decodedToken

    try {
      decodedToken = await adminAuth.verifyIdToken(token)
    } catch (error: any) {
      return NextResponse.json(
        { success: false, error: 'Invalid or expired token' },
        { status: 401 }
      )
    }

    const { searchParams } = new URL(req.url)
    const refId = searchParams.get('refId')

    if (!refId) {
      return NextResponse.json(
        { success: false, error: 'Missing reference ID' },
        { status: 400 }
      )
    }

    // Fetch reference document from Firestore
    const refDoc = await adminDb.collection('references').doc(refId).get()

    if (!refDoc.exists) {
      return NextResponse.json(
        { success: false, error: 'Reference not found' },
        { status: 404 }
      )
    }

    const refData = refDoc.data()

    // Verify user has access to this reference
    const userId = decodedToken.uid
    if (refData?.buyerId !== userId && refData?.sellerId !== userId) {
      return NextResponse.json(
        { success: false, error: 'Unauthorized access to this reference' },
        { status: 403 }
      )
    }

    return NextResponse.json(
      {
        success: true,
        data: {
          refId: refData?.refId,
          status: refData?.status, // 'pending', 'success', or 'failed'
          valueReceived: refData?.valueReceived,
          withdrawn: refData?.withdrawn,
        },
      },
      { status: 200 }
    )
  } catch (error: any) {
    console.error('Error verifying payment:', error)
    return NextResponse.json(
      {
        success: false,
        error: error.message || 'Failed to verify payment',
      },
      { status: 500 }
    )
  }
}
